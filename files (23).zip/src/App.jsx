import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import QuestionPage from './pages/Question';
import Filters from './pages/Filters';
import Analytics from './pages/Analytics';
import Gamification from './pages/Gamification';
import AIHelp from './pages/AIHelp';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/app" element={<Dashboard />} />
      <Route path="/app/question/:id" element={<QuestionPage />} />
      <Route path="/app/filters" element={<Filters />} />
      <Route path="/app/analytics" element={<Analytics />} />
      <Route path="/app/gamification" element={<Gamification />} />
      <Route path="/app/ai" element={<AIHelp />} />
    </Routes>
  );
}