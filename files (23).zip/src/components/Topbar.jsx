import React from 'react';
import { BellIcon, UserCircleIcon, ChartBarIcon } from '@heroicons/react/24/outline';
export default function Topbar({ onOpenMenu }) {
  return (
    <div className="w-full flex items-center justify-between py-3 px-4 border-b border-white/3">
      <div className="flex items-center gap-4">
        <button className="md:hidden text-neon" onClick={onOpenMenu}>☰</button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-neon to-neon/60 flex items-center justify-center text-navy-900 font-bold">OE</div>
          <div>
            <div className="text-sm text-white/80 leading-4">Welcome back</div>
            <div className="text-sm font-semibold">Student</div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="p-2 rounded-lg hover:bg-white/2 transition">
          <BellIcon className="w-6 h-6 text-white/70" />
        </button>
        <button className="p-2 rounded-lg hover:bg-white/2 transition">
          <ChartBarIcon className="w-6 h-6 text-white/70" />
        </button>
        <div className="flex items-center gap-3 px-3 py-1 rounded-lg bg-white/2">
          <UserCircleIcon className="w-6 h-6 text-white/80" />
          <div className="text-sm">Student</div>
        </div>
      </div>
    </div>
  );
}