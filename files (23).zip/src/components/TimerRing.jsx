import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function TimerRing({ total, remaining }) {
  const percent = Math.max(0, Math.min(1, remaining / total));
  const stroke = 28;
  const size = 88;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * percent;
  const color = percent > 0.5 ? '#00E5FF' : percent > 0.2 ? '#FFB86B' : '#FF6B6B';

  return (
    <motion.div className="timer-ring" initial={{ scale: 0.9 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <linearGradient id="g1" x1="0" x2="1">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="100%" stopColor="#00BFFF" />
          </linearGradient>
        </defs>
        <circle cx={size/2} cy={size/2} r={radius} stroke="rgba(255,255,255,0.04)" strokeWidth={stroke} fill="transparent" />
        <motion.circle
          cx={size/2}
          cy={size/2}
          r={radius}
          stroke="url(#g1)"
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="transparent"
          strokeDasharray={`${dash} ${circumference - dash}`}
          style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}
        />
      </svg>
      <div className="absolute text-sm font-semibold text-white">{remaining}s</div>
    </motion.div>
  );
}