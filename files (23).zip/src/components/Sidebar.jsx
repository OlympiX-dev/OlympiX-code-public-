import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon, PuzzlePieceIcon, Bars3Icon, ClipboardDocumentListIcon, SparklesIcon } from '@heroicons/react/24/outline';

export default function Sidebar() {
  return (
    <aside className="w-72 p-6 border-r border-white/4 h-screen hidden md:block">
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon to-neon/60 flex items-center justify-center text-navy-900 font-extrabold text-xl">OE</div>
          <div>
            <div className="text-sm text-white/70">OlympEdge</div>
            <div className="text-xl font-bold">Premium</div>
          </div>
        </div>
      </div>

      <nav className="flex flex-col gap-2">
        <NavLink to="/app" className={({isActive}) => `flex items-center gap-3 px-3 py-2 rounded-lg ${isActive ? 'bg-white/5 ring-1 ring-neon' : 'hover:bg-white/2'}`}>
          <HomeIcon className="w-5 h-5 text-neon" /> <span className="font-medium">Dashboard</span>
        </NavLink>
        <NavLink to="/app/question/1" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/2">
          <PuzzlePieceIcon className="w-5 h-5 text-white/80" /> <span>Practice</span>
        </NavLink>
        <NavLink to="/app/filters" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/2">
          <Bars3Icon className="w-5 h-5 text-white/80" /> <span>Filters</span>
        </NavLink>
        <NavLink to="/app/analytics" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/2">
          <ClipboardDocumentListIcon className="w-5 h-5 text-white/80" /> <span>Analytics</span>
        </NavLink>
        <NavLink to="/app/gamification" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/2">
          <SparklesIcon className="w-5 h-5 text-white/80" /> <span>Gamification</span>
        </NavLink>
      </nav>

      <div className="mt-8 text-xs text-white/60">
        <div className="mb-2">Olympiad Categories</div>
        <div className="grid grid-cols-1 gap-2">
          <div className="px-3 py-2 rounded-lg card accent-gradient">IMO</div>
          <div className="px-3 py-2 rounded-lg card accent-gradient">NSO</div>
          <div className="px-3 py-2 rounded-lg card accent-gradient">IOQM</div>
          <div className="px-3 py-2 rounded-lg card accent-gradient">NSTSE</div>
          <div className="px-3 py-2 rounded-lg card accent-gradient">VVM</div>
        </div>
      </div>
    </aside>
  );
}