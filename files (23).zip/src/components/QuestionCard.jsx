import React from 'react';
import { motion } from 'framer-motion';

export default function QuestionCard({ question, onSelect, disabled, selected }) {
  return (
    <motion.div layout className="card p-6 rounded-2xl shadow-neon">
      <div className="mb-4">
        <div className="text-sm text-white/70">Question</div>
        <div className="mt-2 text-lg md:text-xl font-semibold" dangerouslySetInnerHTML={{ __html: question.body }} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
        {question.choices.map((c) => (
          <motion.button
            layout
            key={c.idx}
            onClick={() => onSelect(c.idx)}
            disabled={disabled}
            initial={{ opacity: 0.98 }}
            whileHover={{ scale: disabled ? 1 : 1.02 }}
            className={`p-4 rounded-xl text-left border ${selected===c.idx ? 'ring-2 ring-neon bg-white/3' : 'hover:bg-white/2'} transition`}
          >
            <div className="font-medium text-white/90" dangerouslySetInnerHTML={{ __html: c.text }} />
            {c.image_url && <img src={c.image_url} alt="" className="mt-2 rounded-md max-h-36 w-full object-contain" />}
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}