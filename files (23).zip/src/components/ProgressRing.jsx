import React from 'react';

export default function ProgressRing({ value = 50 }) {
  const size = 88;
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const percent = value / 100;
  const dash = circumference * percent;

  return (
    <div className="relative w-24 h-24">
      <svg width={size} height={size}>
        <circle cx={size/2} cy={size/2} r={radius} stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} fill="transparent"/>
        <circle cx={size/2} cy={size/2} r={radius} stroke="#00E5FF" strokeWidth={stroke} strokeLinecap="round" fill="transparent" strokeDasharray={`${dash} ${circumference-dash}`} style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}/>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-sm text-white/80 font-semibold">{value}%</div>
        <div className="text-xs text-white/60">Complete</div>
      </div>
    </div>
  );
}