import React, { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import { supabase } from '../lib/supabaseClient';
import { Link } from 'react-router-dom';

export default function Filters() {
  const [olympiads, setOlympiads] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);
  const [topics, setTopics] = useState([]);

  const [sel, setSel] = useState({ olympiad: null, classLevel: null, subject: null, chapter: null, topic: null });

  useEffect(() => {
    async function load() {
      const [oRes, cRes, sRes] = await Promise.all([
        supabase.from('olympiad_types').select('*'),
        supabase.from('class_levels').select('*').order('id'),
        supabase.from('subjects').select('*')
      ]);
      setOlympiads(oRes.data || []);
      setClasses(cRes.data || []);
      setSubjects(sRes.data || []);
    }
    load();
  }, []);

  useEffect(() => {
    async function loadChaps() {
      if (!sel.subject || !sel.classLevel) return setChapters([]);
      const { data } = await supabase.from('chapters').select('*').match({ subject_id: sel.subject, class_level_id: sel.classLevel });
      setChapters(data || []);
    }
    loadChaps();
  }, [sel.subject, sel.classLevel]);

  useEffect(() => {
    async function loadTopics() {
      if (!sel.chapter) return setTopics([]);
      const { data } = await supabase.from('topics').select('*').eq('chapter_id', sel.chapter);
      setTopics(data || []);
    }
    loadTopics();
  }, [sel.chapter]);

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1">
        <Topbar />
        <main className="p-6">
          <div className="card p-6 rounded-2xl">
            <h2 className="text-2xl font-bold">Filters</h2>
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-xs text-white/70">Olympiad</div>
                <select value={sel.olympiad||''} onChange={e=>setSel(s=>({...s, olympiad: e.target.value||null}))} className="mt-2 w-full p-3 rounded-lg bg-white/3">
                  <option value="">Any</option>
                  {olympiads.map(o=> <option key={o.id} value={o.id}>{o.code}</option>)}
                </select>
              </div>

              <div>
                <div className="text-xs text-white/70">Class</div>
                <select value={sel.classLevel||''} onChange={e=>setSel(s=>({...s, classLevel: e.target.value||null}))} className="mt-2 w-full p-3 rounded-lg bg-white/3">
                  <option value="">Any</option>
                  {classes.map(c=> <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>

              <div>
                <div className="text-xs text-white/70">Subject</div>
                <select value={sel.subject||''} onChange={e=>setSel(s=>({...s, subject: e.target.value||null}))} className="mt-2 w-full p-3 rounded-lg bg-white/3">
                  <option value="">Any</option>
                  {subjects.map(s=> <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>

              <div>
                <div className="text-xs text-white/70">Chapter</div>
                <select value={sel.chapter||''} onChange={e=>setSel(s=>({...s, chapter: e.target.value||null}))} className="mt-2 w-full p-3 rounded-lg bg-white/3">
                  <option value="">Any</option>
                  {chapters.map(c=> <option key={c.id} value={c.id}>{c.title}</option>)}
                </select>
              </div>

              <div>
                <div className="text-xs text-white/70">Topic</div>
                <select value={sel.topic||''} onChange={e=>setSel(s=>({...s, topic: e.target.value||null}))} className="mt-2 w-full p-3 rounded-lg bg-white/3">
                  <option value="">Any</option>
                  {topics.map(t=> <option key={t.id} value={t.id}>{t.title}</option>)}
                </select>
              </div>

              <div className="flex items-end">
                <Link to="/app/question/1" className="w-full px-4 py-3 rounded-lg bg-neon text-navy-900 text-center">Start Practice</Link>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}