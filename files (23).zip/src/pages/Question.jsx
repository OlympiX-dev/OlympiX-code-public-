import React, { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import QuestionCard from '../components/QuestionCard';
import TimerRing from '../components/TimerRing';
import { supabase } from '../lib/supabaseClient';
import { useParams, Link } from 'react-router-dom';

export default function QuestionPage() {
  const { id } = useParams();
  const [question, setQuestion] = useState(null);
  const [remaining, setRemaining] = useState(0);
  const [selected, setSelected] = useState(null);
  const [locked, setLocked] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('questions').select('*, question_choices(idx, text, image_url)').eq('is_published', true).eq('id', id).single();
      if (data) {
        const q = {
          id: data.id,
          body: data.body,
          explanation: data.explanation,
          time_limit_seconds: data.time_limit_seconds,
          choices: (data.question_choices || []).sort((a,b)=>a.idx-b.idx).map(c=>({ idx: c.idx, text: c.text, image_url: c.image_url }))
        };
        setQuestion(q);
        setRemaining(q.time_limit_seconds);
      }
    }
    load();
  }, [id]);

  useEffect(() => {
    if (!question) return;
    const t = setInterval(() => {
      setRemaining(r => {
        if (r <= 1) {
          clearInterval(t);
          if (!locked) handleSubmit(null, true);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [question]);

  async function handleSelect(idx) {
    if (locked) return;
    setSelected(idx);
    setLocked(true);
    handleSubmit(idx, false);
  }

  async function handleSubmit(idx, timeout=false) {
    const payload = {
      question_id: question.id,
      chosen_idx: idx === null ? null : idx,
      time_taken_seconds: question.time_limit_seconds - remaining,
      user_identifier: null,
      mode: 'topic_practice',
      reveal_explanation: true
    };
    // call Edge Function
    const fn = `${import.meta.env.VITE_SUPABASE_FUNCTION_URL || 'https://your-project.functions.supabase.co'}/check-answer`;
    const token = import.meta.env.VITE_CHECK_TOKEN || '';
    try {
      const res = await fetch(fn, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-check-token': token },
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      setResult(json);
    } catch (e) {
      console.error(e);
      setResult({ correct: false });
    }
  }

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              {question ? (
                <QuestionCard question={question} onSelect={handleSelect} disabled={locked} selected={selected} />
              ) : (
                <div className="card p-6 rounded-2xl">Loading...</div>
              )}
              {result && (
                <div className={`mt-4 p-4 rounded-lg ${result.correct ? 'bg-green-900/40 ring-1 ring-green-400' : 'bg-red-900/30 ring-1 ring-red-400'}`}>
                  <div className="font-semibold">{result.correct ? 'Correct' : 'Incorrect'}</div>
                  {result.explanation && <div className="text-sm mt-2 text-white/80" dangerouslySetInnerHTML={{ __html: result.explanation }} />}
                  <div className="mt-3 flex gap-3">
                    <Link to="/app" className="px-4 py-2 rounded-lg bg-white/3">Back to Dashboard</Link>
                    <Link to="/app/question/1" className="px-4 py-2 rounded-lg bg-neon text-navy-900">Next</Link>
                  </div>
                </div>
              )}
            </div>

            <aside>
              <div className="card p-6 rounded-2xl">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white/70">Timer</div>
                    <div className="text-xs text-white/60">Remaining</div>
                  </div>
                  <TimerRing total={question?.time_limit_seconds || 120} remaining={remaining} />
                </div>

                <div className="mt-6">
                  <div className="text-sm text-white/70">Hints</div>
                  <div className="mt-2 text-sm text-white/80">AI-powered hints are available for wrong answers.</div>
                  <a href="/app/ai" className="mt-4 inline-block px-4 py-2 rounded-lg bg-white/3">Ask AI</a>
                </div>
              </div>

              <div className="card p-6 rounded-2xl mt-4">
                <h4 className="text-sm text-white/70">Question Details</h4>
                <div className="mt-2 text-xs text-white/60">Difficulty: <span className="font-semibold text-white/80">Olympiad</span></div>
                <div className="mt-1 text-xs text-white/60">Subject: Maths • Chapter: Number Systems</div>
              </div>
            </aside>
          </div>
        </main>
      </div>
    </div>
  );
}