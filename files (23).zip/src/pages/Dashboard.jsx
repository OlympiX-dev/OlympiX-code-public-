import React from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import ProgressRing from '../components/ProgressRing';

export default function Dashboard() {
  const progress = 67;
  const streak = 4;
  const recent = [
    { id: 1, title: 'Number Theory: Divisibility', correct: 8, total: 10 },
    { id: 2, title: 'Algebra: Quadratics', correct: 5, total: 8 },
    { id: 3, title: 'Geometry: Angles', correct: 6, total: 7 }
  ];

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="card p-6 rounded-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">Your Progress</h2>
                  <p className="text-sm text-white/70 mt-1">Keep the streak going — practice daily to improve faster.</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-xs text-white/70">Streak</div>
                    <div className="text-3xl font-extrabold text-neon">{streak}</div>
                  </div>
                  <div>
                    <ProgressRing value={progress} />
                  </div>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-white/3">
                  <div className="text-xs text-white/70">Accuracy</div>
                  <div className="text-xl font-semibold">72%</div>
                </div>
                <div className="p-4 rounded-lg bg-white/3">
                  <div className="text-xs text-white/70">Avg Speed</div>
                  <div className="text-xl font-semibold">58s / Q</div>
                </div>
                <div className="p-4 rounded-lg bg-white/3">
                  <div className="text-xs text-white/70">Weak Topics</div>
                  <div className="text-xl font-semibold">3</div>
                </div>
              </div>
            </div>

            <div className="card p-6 rounded-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Recent Practice</h3>
                <Link to="/app/analytics" className="text-sm text-white/70">View all</Link>
              </div>

              <div className="mt-4 grid gap-3">
                {recent.map(r => (
                  <motion.div key={r.id} className="p-4 rounded-lg bg-white/2 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold">{r.title}</div>
                      <div className="text-xs text-white/70">{r.correct}/{r.total} correct</div>
                    </div>
                    <div className="text-sm font-semibold text-neon">{Math.round((r.correct/r.total)*100)}%</div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="card p-6 rounded-2xl">
              <h3 className="text-lg font-bold">Quick Start</h3>
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
                <Link to="/app/question/1" className="p-3 rounded-lg bg-white/3 text-center">Topic Practice</Link>
                <Link to="/app/question/1" className="p-3 rounded-lg bg-white/3 text-center">Mock Test</Link>
                <Link to="/app/question/1" className="p-3 rounded-lg bg-white/3 text-center">Speed Challenge</Link>
                <Link to="/app/filters" className="p-3 rounded-lg bg-white/3 text-center">Filters</Link>
              </div>
            </div>
          </div>

          <aside className="space-y-6">
            <div className="card p-6 rounded-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-white/70">XP</div>
                  <div className="text-2xl font-extrabold">3,240</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-white/70">Level</div>
                  <div className="text-xl font-bold">12</div>
                </div>
              </div>
              <div className="mt-4">
                <div className="w-full h-3 bg-white/6 rounded-full overflow-hidden">
                  <div className="h-3 bg-neon" style={{ width: `${progress}%` }} />
                </div>
                <div className="text-xs text-white/60 mt-2">Next level at 5000 XP</div>
              </div>
            </div>

            <div className="card p-6 rounded-2xl">
              <h4 className="text-sm text-white/70">Upcoming Mock</h4>
              <div className="mt-2 font-semibold">NSO • Class 8</div>
              <div className="text-xs text-white/60 mt-3">Starts in: 03d 04h</div>
              <button className="mt-4 w-full px-4 py-2 rounded-lg bg-neon text-navy-900 font-semibold">Register</button>
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}