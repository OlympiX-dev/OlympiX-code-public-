import React from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import { Bar } from 'react-chartjs-2'; // optional - placeholder; include CDN or replace with simple bars

export default function Analytics() {
  // placeholder static data
  const accuracyData = {
    labels: ['Algebra','Number Theory','Geometry','Combinatorics','Physics'],
    datasets: [{ label: 'Accuracy %', data: [78, 62, 84, 55, 72], backgroundColor: 'rgba(0,229,255,0.18)', borderColor: '#00E5FF', borderWidth: 1 }]
  };

  const weakTopics = [
    { title: 'Combinatorics', accuracy: 55 },
    { title: 'Number Theory', accuracy: 62 },
    { title: 'Kinematics', accuracy: 65 }
  ];

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1">
        <Topbar />
        <main className="p-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 card p-6 rounded-2xl">
              <h3 className="text-lg font-bold">Progress Over Time</h3>
              <div className="mt-4 h-64 flex items-center justify-center text-white/60">[Interactive graph placeholder]</div>
            </div>

            <aside className="space-y-6">
              <div className="card p-6 rounded-2xl">
                <h4 className="text-sm text-white/70">Accuracy by Topic</h4>
                <div className="mt-4 text-sm text-white/80">Overall performance</div>
                <div className="mt-4">
                  {weakTopics.map(w => (
                    <div key={w.title} className="flex items-center justify-between py-2">
                      <div>{w.title}</div>
                      <div className="font-semibold text-neon">{w.accuracy}%</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card p-6 rounded-2xl">
                <h4 className="text-sm text-white/70">Leaderboard</h4>
                <div className="mt-3">
                  <div className="flex items-center justify-between py-2">
                    <div>Student A</div><div className="text-sm text-neon">3,800 XP</div>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div>Student B</div><div className="text-sm text-white/70">2,940 XP</div>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div>You</div><div className="text-sm font-bold">3,240 XP</div>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </main>
      </div>
    </div>
  );
}