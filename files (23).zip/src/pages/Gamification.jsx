import React from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';

export default function Gamification() {
  const badges = [
    { code: 'first_win', name: 'First Win', desc: 'Complete your first practice' },
    { code: 'streak_7', name: '7-day Streak', desc: 'Practice 7 days in a row' },
    { code: 'speed_demon', name: 'Speed Demon', desc: 'Top 10% in speed challenge' }
  ];
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1">
        <Topbar />
        <main className="p-6">
          <div className="card p-6 rounded-2xl">
            <h2 className="text-2xl font-bold">Gamification</h2>
            <div className="mt-4 flex items-center justify-between">
              <div>
                <div className="text-xs text-white/70">XP</div>
                <div className="text-3xl font-extrabold">3,240</div>
              </div>
              <div>
                <div className="text-xs text-white/70">Level</div>
                <div className="text-3xl font-extrabold">12</div>
              </div>
              <div>
                <div className="text-xs text-white/70">Streak</div>
                <div className="text-3xl font-extrabold text-neon">4</div>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              {badges.map(b => (
                <div key={b.code} className="p-4 rounded-xl card text-center">
                  <div className="w-16 h-16 mx-auto rounded-full bg-white/3 flex items-center justify-center text-neon font-bold text-lg">{b.name[0]}</div>
                  <div className="mt-3 font-semibold">{b.name}</div>
                  <div className="text-xs text-white/70 mt-1">{b.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}