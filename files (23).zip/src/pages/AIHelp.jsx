import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';

export default function AIHelp() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState(null);
  const sample = "Explain why I got question #12 wrong: modular arithmetic approach.";

  async function askAI() {
    setResponse('Thinking...');
    // placeholder - in production call your AI endpoint
    await new Promise(r => setTimeout(r, 900));
    setResponse(`<p><strong>Hint:</strong> Reduce powers modulo 7. Notice 3^n cycles with period 6. Use that to determine n mod 6.</p>`);
  }

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1">
        <Topbar />
        <main className="p-6">
          <div className="card p-6 rounded-2xl">
            <h2 className="text-2xl font-bold">AI Tutor</h2>
            <p className="text-sm text-white/70 mt-2">Ask the AI to explain wrong answers or give hints.</p>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={sample} className="md:col-span-2 p-4 rounded-lg bg-white/3 h-40" />
              <div>
                <div className="text-xs text-white/70">Quick prompts</div>
                <button onClick={() => setPrompt(sample)} className="mt-2 w-full p-3 rounded-lg bg-white/3">Sample: Explain modular</button>
                <button onClick={() => setPrompt('Give a hint for speed solving combinatorics problems')} className="mt-2 w-full p-3 rounded-lg bg-white/3">Hint: Combinatorics</button>
                <button onClick={() => setPrompt('Step-by-step solution for question ID 45')} className="mt-2 w-full p-3 rounded-lg bg-neon text-navy-900">Try AI</button>
              </div>
            </div>

            <div className="mt-6">
              <button onClick={askAI} className="px-4 py-2 rounded-lg bg-neon text-navy-900">Ask AI</button>
            </div>

            <div className="mt-6 card p-4 rounded-xl">
              <div dangerouslySetInnerHTML={{ __html: response || '<em>No response yet</em>' }} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}