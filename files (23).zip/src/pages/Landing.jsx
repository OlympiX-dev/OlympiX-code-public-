import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-8 px-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon to-neon/60 flex items-center justify-center text-navy-900 font-bold">OE</div>
          <div>
            <div className="text-white/80 text-sm">OlympEdge</div>
            <div className="text-2xl font-extrabold">Premium Olympiad Prep</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/app" className="px-4 py-2 rounded-lg bg-neon text-navy-900 font-semibold shadow-neon">Try Demo</Link>
          <a href="#" className="text-white/70">Login</a>
        </div>
      </header>

      <main className="flex-1 px-6 md:px-12">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <motion.h1 initial={{ x: -40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.1 }} className="text-4xl md:text-6xl font-extrabold leading-tight">
              Ace Olympiads with <span className="text-neon">Smart Practice</span> and Real Analytics
            </motion.h1>
            <motion.p initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.25 }} className="mt-6 text-white/80 max-w-xl">
              Practice thousands of curated olympiad questions across IMO, NSO, IOQM, NSTSE & VVM. Timed tests, weakness drills, and AI explanations — all in one premium app.
            </motion.p>

            <div className="mt-8 flex gap-4">
              <Link to="/app" className="px-6 py-3 rounded-full bg-neon text-navy-900 font-semibold shadow-neon">Start Practicing</Link>
              <a href="#features" className="px-6 py-3 rounded-full border border-white/6 text-white/80">How it works</a>
            </div>

            <div id="features" className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="card p-4 rounded-xl accent-gradient">
                <div className="text-sm text-white/70">Timed Mocks</div>
                <div className="font-semibold mt-2">Real exam experience</div>
              </div>
              <div className="card p-4 rounded-xl accent-gradient">
                <div className="text-sm text-white/70">Smart Practice</div>
                <div className="font-semibold mt-2">Target your weak topics</div>
              </div>
              <div className="card p-4 rounded-xl accent-gradient">
                <div className="text-sm text-white/70">AI Help</div>
                <div className="font-semibold mt-2">Hints & detailed explanations</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="card p-6 rounded-3xl shadow-neon">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-xs text-white/70">Daily Challenge</div>
                  <div className="text-lg font-bold">10 Questions • 20 Minutes</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-white/70">Streak</div>
                  <div className="text-2xl font-extrabold text-neon">4</div>
                </div>
              </div>
              <div className="mt-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-white/3">IMO • Class 10</div>
                  <div className="p-3 rounded-lg bg-white/3">NSO • Class 8</div>
                </div>
              </div>
            </div>

            <div className="absolute -right-6 -top-10 w-64 h-64 rounded-full bg-gradient-to-br from-neon/15 to-neon/6 blur-3xl"></div>
          </div>
        </section>

        <section className="mt-16 mb-12">
          <h3 className="text-xl font-bold mb-4">Popular Olympiads</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {['IMO','NSO','IOQM','NSTSE','VVM'].map(o => (
              <div key={o} className="card p-4 rounded-xl flex flex-col items-start gap-2">
                <div className="text-sm text-white/70">{o}</div>
                <div className="text-lg font-semibold">{o} Prep</div>
                <div className="text-xs text-white/60">Curated questions & mocks</div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="py-8 px-6 text-center text-white/60 text-sm">
        © {new Date().getFullYear()} OlympEdge — Built for serious learners
      </footer>
    </div>
  );
}