module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          900: '#071026',
          800: '#071733',
          700: '#0b2340'
        },
        neon: {
          DEFAULT: '#00E5FF',
          400: '#00BFFF'
        },
        glass: 'rgba(255,255,255,0.06)'
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui']
      },
      boxShadow: {
        neon: '0 6px 24px rgba(0,229,255,0.08), inset 0 1px 0 rgba(255,255,255,0.02)'
      }
    }
  },
  plugins: []
};