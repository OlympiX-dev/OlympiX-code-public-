Frontend prototype (Vite + React + Tailwind)

1. Install
   npm install

2. Configure .env (create from .env.example)

3. Run dev
   npm run dev

This prototype connects to Supabase via the public anon key for reads; the Edge Function (check-answer) endpoint and token are used for secure answer checking and attempt recording.